#include "led.h"
#include "stm32f10x.h"

void LED_Init(void)
{
	GPIO_InitTypeDef led_inistruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	led_inistruct.GPIO_Pin =GPIO_Pin_1;
	led_inistruct.GPIO_Speed = GPIO_Speed_50MHz;
	led_inistruct.GPIO_Mode = GPIO_Mode_Out_PP;
	
	 GPIO_Init(GPIOA,&led_inistruct );
	
	 
	
}







