#include "stm32f10x.h"
#include "main.h"
#include "led.h"
#include "usart.h"
#include "tim.h"
#include "SysTick.h"
#include "oled.h"


int  main()
{
	LED_Init();
	
	


	
	while(1)
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_1);
		ms_delay(500);
		GPIO_SetBits(GPIOA,GPIO_Pin_1);
		ms_delay(500);

}
	
	
}	
	
	
	
	

