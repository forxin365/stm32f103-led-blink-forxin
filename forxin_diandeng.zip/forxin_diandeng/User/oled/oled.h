#ifndef  _OLED_H_
#define 	_OLED_H

#include "stm32f10x.h"
#define OLED_ADDRESS 0x78
void I2C_Configuration(void);
void T2C_WriteByte(uint8_t addr,uint8_t data);
void WriteCmd(unsigned char I2C_Command);
void WriteDat(unsigned char I2C_Data);
void OLED_Init(void);
void OLED_SetPos(unsigned char x,unsigned char y);
void OLED_Fill(unsigned char Fill_Data);
void OLED_CLS(void);
void OLED_ON(void);
void OLED_OFF(void);
void OLED_ShowStr(unsigned char x,unsigned y,unsigned  char ch[],unsigned TextSize);


#endif






