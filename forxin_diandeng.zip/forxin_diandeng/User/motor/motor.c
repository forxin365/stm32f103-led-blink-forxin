#include "motor.h"
#include "stm32f10x.h"

void motor_config(void)
{
	GPIO_InitTypeDef GPIO_MotorInir;
	TIM_TimeBaseInitTypeDef TIM_MotorInit;
	TIM_OCInitTypeDef TIMPWM_MotorInit;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	
	GPIO_PinRemapConfig( GPIO_PartialRemap_TIM3, ENABLE);

	
	GPIO_MotorInir.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_MotorInir.GPIO_Pin	 = GPIO_Pin_5;
	GPIO_MotorInir.GPIO_Speed=GPIO_Speed_50MHz;
	 GPIO_Init(GPIOB,&GPIO_MotorInir );
	
	TIM_MotorInit.TIM_ClockDivision = TIM_CKD_DIV1;						//����ʱ�ӷָ�
	TIM_MotorInit.TIM_CounterMode		= TIM_CounterMode_Up;			//���ϵ�ģʽ
	TIM_MotorInit.TIM_Period				= 200-1;									//��������һ�������¼�װ�����Զ���װ��ֵ
	TIM_MotorInit.TIM_Prescaler			= 7200-1;									//ʱ��Ƶ�ʵ�Ԥ��Ƶֵ
	TIM_TimeBaseInit(TIM3,&TIM_MotorInit );

	TIMPWM_MotorInit.TIM_OCMode      =  TIM_OCMode_PWM1;					//ѡ��ʱ��ģʽ
	TIMPWM_MotorInit.TIM_OutputState =  TIM_OutputState_Enable;		//�Ƚ����ʹ��
	TIMPWM_MotorInit.TIM_OCPolarity  =  TIM_OCPolarity_Low;				//ѡ���������
	TIM_OC2Init(TIM3, &TIMPWM_MotorInit);
	TIM_OC2PreloadConfig(TIM3,TIM_OCPreload_Enable);
	TIM_Cmd(TIM3,ENABLE);
	

}





















