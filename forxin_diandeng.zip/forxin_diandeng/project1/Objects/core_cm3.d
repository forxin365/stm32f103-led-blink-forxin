.\objects\core_cm3.o: ..\Libraries\CMSIS\core_cm3.c
.\objects\core_cm3.o: D:\sofeware\keil5\core\ARM\ARMCC\Bin\..\include\stdint.h
